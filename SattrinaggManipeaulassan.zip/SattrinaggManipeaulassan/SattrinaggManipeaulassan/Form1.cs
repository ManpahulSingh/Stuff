﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace SattrinaggManipeaulassan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Only displays numbers
            /*string inp = textBox1.Text;
            //char[] inp = textBox1.Text.ToCharArray();
            string oup = "";
            label1.Text = "Output is: ";
            for (int i = 0; i < inp.Length; i++)
            {
                if(char.IsDigit(inp[i]))
                {
                    oup += inp[i];
                }
            }
            label1.Text += oup;
            */
            //White space error message
            /*for (int i = 0; i < textBox1.Text.Length; i++)
            {
                if(char.IsWhiteSpace(textBox1.Text[i]))
                {
                    MessageBox.Show("This field should not contain a space");
                    break;
                }
            }*/

            //If the first character of the string is a number, it will remove it
            /*if (char.IsDigit(textBox1.Text, 0))
                label1.Text = textBox1.Text.Substring(1);

            else
                label1.Text = textBox1.Text;
                */

            //adds "-" after 5th character
            /*if     (textBox1.TextLength > 5)
            {   
                    textBox1.Text = textBox1.Text.Insert(5, "-");
            }
            */

            //trimming white spaces and characters
            /*
            textBox1.Text = textBox1.Text.Trim();
            */

            //splitting a string in an array
            /*string[] bhaelu = textBox1.Text.Split(' ');

            label2.Text = "";

            for (int i = 0; i < bhaelu.Length; i++)
            {
                label2.Text += bhaelu[i] + "\n" ;
            }*/

            /*null string and empty string are different*/

            //Try Parse
            /*int x;
            if(int.TryParse(textBox1.Text, out x))
                label2.Text = x.ToString();
             */

            /*textBox1.Text = textBox1.Text.Trim().ToUpper();
            textBox2.Text = textBox2.Text.Trim().ToUpper();

            if (textBox3.TextLength > 5)
            {
                textBox3.Text = textBox3.Text.Insert(5, "-");
            }

            if(textBox4.Text.Length > 6)
            {
                MessageBox.Show("Only 6 characters plx");
            }*/

            /*
            string aaa = string.Format("I am a {0} Tada ta tada", "disco dancer");
            MessageBox.Show(aaa);*/

            string bel = textBox1.Text;
            //Regex asd = new Regex(@"\d\d\d\d\d-\d\d\d\d\d$");
            Regex asd = new Regex(@"['+','*']\d\d-\d\d\d\d\d-\d\d\d\d\d$");
            if (asd.IsMatch(bel))
            {
                MessageBox.Show("match");
            }

            else
            {
                MessageBox.Show("no match");
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
